//
//  RickAndMortyAPIApp.swift
//  RickAndMortyAPI
//
//  Created by Andre Gerez Foratto on 10/05/24.
//

import SwiftUI

@main
struct RickAndMortyAPIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
